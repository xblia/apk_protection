package com.example.xblia2.androidjnitest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.bangcle.protect.ACall;
import com.bangcle.protect.Util;

public class JNIReceiver
  extends BroadcastReceiver
{
  private BroadcastReceiver realReceiver = null;
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if (Util.getCustomClassLoader() == null) {
      Util.runAll(paramContext);
    }
    try
    {
      this.realReceiver = ((BroadcastReceiver)Util.getCustomClassLoader().loadClass(getClass().getName()).newInstance());
      if (this.realReceiver != null)
      {
        ACall.getACall().c1(this, this.realReceiver);
        this.realReceiver.onReceive(paramContext, paramIntent);
        ACall.getACall().c2(this, this.realReceiver);
      }
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
        this.realReceiver = null;
      }
    }
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_bangbang.jar
 * Qualified Name:     com.example.xblia2.androidjnitest.JNIReceiver
 * JD-Core Version:    0.7.0.1
 */