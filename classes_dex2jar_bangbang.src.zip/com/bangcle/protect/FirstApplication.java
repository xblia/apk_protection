package com.bangcle.protect;

import android.app.Application;

public class FirstApplication
  extends Application
{
  public void onCreate()
  {
    super.onCreate();
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_bangbang.jar
 * Qualified Name:     com.bangcle.protect.FirstApplication
 * JD-Core Version:    0.7.0.1
 */