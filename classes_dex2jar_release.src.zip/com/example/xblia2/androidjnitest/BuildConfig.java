package com.example.xblia2.androidjnitest;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.example.xblia2.androidjnitest";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.0";
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     com.example.xblia2.androidjnitest.BuildConfig
 * JD-Core Version:    0.7.0.1
 */