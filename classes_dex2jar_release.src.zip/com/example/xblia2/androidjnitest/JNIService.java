package com.example.xblia2.androidjnitest;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class JNIService
  extends Service
{
  public IBinder onBind(Intent paramIntent)
  {
    throw new UnsupportedOperationException("Not yet implemented");
  }
  
  public void onCreate()
  {
    super.onCreate();
    Toast.makeText(this, "Service start JNI", 1).show();
  }
  
  public void onDestroy()
  {
    super.onDestroy();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     com.example.xblia2.androidjnitest.JNIService
 * JD-Core Version:    0.7.0.1
 */