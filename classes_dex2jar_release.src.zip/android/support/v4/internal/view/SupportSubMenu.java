package android.support.v4.internal.view;

import android.view.SubMenu;

public abstract interface SupportSubMenu
  extends SupportMenu, SubMenu
{}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.internal.view.SupportSubMenu
 * JD-Core Version:    0.7.0.1
 */