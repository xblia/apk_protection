package android.support.v7.app;

@Deprecated
public class ActionBarActivity
  extends AppCompatActivity
{}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v7.app.ActionBarActivity
 * JD-Core Version:    0.7.0.1
 */