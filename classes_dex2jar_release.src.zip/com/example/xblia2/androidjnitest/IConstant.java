package com.example.xblia2.androidjnitest;

public class IConstant
{
  public static final String JNI_RECEIVER_ACTION = "com.intel.cats.jni.broadcast.action";
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     com.example.xblia2.androidjnitest.IConstant
 * JD-Core Version:    0.7.0.1
 */