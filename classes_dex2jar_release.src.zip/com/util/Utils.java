package com.util;

public class Utils
{
  static
  {
    System.loadLibrary("hello-jni");
  }
  
  public static native int calc(int paramInt1, int paramInt2);
  
  public static native String stringFromJNI();
  
  public static native String unimplementedStringFromJNI();
  
  public static native boolean writeContentToFile(String paramString);
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     com.util.Utils
 * JD-Core Version:    0.7.0.1
 */