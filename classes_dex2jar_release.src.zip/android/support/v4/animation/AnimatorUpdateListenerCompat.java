package android.support.v4.animation;

public abstract interface AnimatorUpdateListenerCompat
{
  public abstract void onAnimationUpdate(ValueAnimatorCompat paramValueAnimatorCompat);
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.animation.AnimatorUpdateListenerCompat
 * JD-Core Version:    0.7.0.1
 */