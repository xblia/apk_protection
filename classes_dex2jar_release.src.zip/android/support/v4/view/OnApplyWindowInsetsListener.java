package android.support.v4.view;

import android.view.View;

public abstract interface OnApplyWindowInsetsListener
{
  public abstract WindowInsetsCompat onApplyWindowInsets(View paramView, WindowInsetsCompat paramWindowInsetsCompat);
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.view.OnApplyWindowInsetsListener
 * JD-Core Version:    0.7.0.1
 */