package com.bangcle.protect;

import android.content.ContentProvider;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build.VERSION;
import android.os.Environment;
import android.os.StatFs;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Field;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;

public class Util
{
  private static String BUILD_TIME;
  public static String CPUABI = null;
  private static String VERSION_NAME;
  private static ClassLoader cl = null;
  static byte[] hexDigits;
  public static boolean isX86;
  private static ArrayList<ContentProvider> ps;
  public static Context x86Ctx;
  
  static
  {
    VERSION_NAME = "1.0";
    BUILD_TIME = "2015-07-1717:18:37";
    ps = new ArrayList();
    x86Ctx = null;
    isX86 = false;
    hexDigits = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
  }
  
  private static void CopyArmLib(Context paramContext)
  {
    String str1 = paramContext.getApplicationInfo().sourceDir;
    try
    {
      JarFile localJarFile = new JarFile(str1);
      try
      {
        Enumeration localEnumeration = localJarFile.entries();
        for (;;)
        {
          if (!localEnumeration.hasMoreElements()) {
            return;
          }
          JarEntry localJarEntry = (JarEntry)localEnumeration.nextElement();
          String str2 = localJarEntry.getName();
          if (str2.equals("assets/libsecexe.so"))
          {
            String str3 = str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + str3, localJarFile, localJarEntry);
          }
          if (str2.equals("assets/libsecmain.so"))
          {
            str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + "libsecmain.so", localJarFile, localJarEntry);
          }
          if (str2.equals("assets/libsecpreload.so"))
          {
            str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + "libsecpreload.so", localJarFile, localJarEntry);
          }
        }
        localIOException1.printStackTrace();
      }
      catch (IOException localIOException1) {}
    }
    catch (IOException localIOException2)
    {
      label223:
      break label223;
    }
  }
  
  private static void CopyBinaryFile(Context paramContext)
  {
    String str1 = "/data/data/" + paramContext.getPackageName() + "/.cache/classes.jar";
    String str2 = "/data/data/" + paramContext.getPackageName() + "/.cache/" + paramContext.getPackageName();
    String str3 = "/data/data/" + paramContext.getPackageName() + "/.cache/" + paramContext.getPackageName() + ".art";
    if (!new File(str1).exists()) {
      ACall.getACall().a1(paramContext.getPackageName().getBytes(), paramContext.getApplicationInfo().sourceDir.getBytes());
    }
    try
    {
      Runtime.getRuntime().exec("chmod 755 " + str2).waitFor();
      Runtime.getRuntime().exec("chmod 755 " + str3).waitFor();
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      localInterruptedException.printStackTrace();
    }
  }
  
  private static void CopyLib(Context paramContext)
  {
    String str1 = paramContext.getApplicationInfo().sourceDir;
    try
    {
      JarFile localJarFile = new JarFile(str1);
      try
      {
        Enumeration localEnumeration = localJarFile.entries();
        for (;;)
        {
          if (!localEnumeration.hasMoreElements()) {
            return;
          }
          JarEntry localJarEntry = (JarEntry)localEnumeration.nextElement();
          String str2 = localJarEntry.getName();
          if (str2.equals("assets/libsecexe.x86.so"))
          {
            String str3 = str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + str3, localJarFile, localJarEntry);
          }
          if (str2.equals("assets/libsecmain.x86.so"))
          {
            str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + "libsecmain.x86.so", localJarFile, localJarEntry);
          }
          if (str2.equals("assets/" + paramContext.getPackageName() + ".x86"))
          {
            str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + paramContext.getPackageName(), localJarFile, localJarEntry);
          }
          if (str2.equals("assets/libsecpreload.x86.so"))
          {
            str2.replaceAll("assets/", "");
            realCopy("/data/data/" + paramContext.getPackageName() + "/.cache/" + "libsecpreload.x86.so", localJarFile, localJarEntry);
          }
        }
        localIOException1.printStackTrace();
      }
      catch (IOException localIOException1) {}
    }
    catch (IOException localIOException2)
    {
      label302:
      break label302;
    }
  }
  
  public static void addProvider(ContentProvider paramContentProvider)
  {
    synchronized (ps)
    {
      x86Ctx = paramContentProvider.getContext();
      ACall.getACall().set5(paramContentProvider);
      return;
    }
  }
  
  public static byte[] calFileMD5(String paramString)
    throws Exception
  {
    FileInputStream localFileInputStream = new FileInputStream(paramString);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte[32768];
    for (;;)
    {
      int i = localFileInputStream.read(arrayOfByte);
      if (i <= 0)
      {
        MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
        localMessageDigest.update(localByteArrayOutputStream.toByteArray());
        return localMessageDigest.digest();
      }
      localByteArrayOutputStream.write(arrayOfByte, 0, i);
    }
  }
  
  private static void checkSpace(Context paramContext)
  {
    if (!isSpaceEnough(paramContext))
    {
      long l1 = getDataSize();
      long l2 = getClassesJarSize(paramContext);
      Log.e("SecApk", "Insufficient Space For SecApk available size:" + l1 + " classSize" + l2);
    }
    try
    {
      Runtime.getRuntime().exec("kill -9 " + android.os.Process.myPid());
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  private static void checkUpdate(Context paramContext)
  {
    try
    {
      localFile1 = new File("/data/data/" + paramContext.getPackageName() + "/.cache/");
      PackageInfo localPackageInfo = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0);
      i = localPackageInfo.versionCode;
      str = localPackageInfo.versionName;
      if (str == null) {
        str = VERSION_NAME;
      }
      localFile3 = new File("/data/data/" + paramContext.getPackageName() + "/.sec_version");
      if (!localFile3.exists())
      {
        deleteDirectory(localFile1);
        writeVersion(localFile3, i, str);
        return;
      }
      arrayOfString = readVersions(localFile3);
      if (arrayOfString == null)
      {
        deleteDirectory(localFile1);
        localFile3.delete();
        return;
      }
    }
    catch (Exception localException)
    {
      File localFile1;
      int i;
      String str;
      File localFile3;
      String[] arrayOfString;
      localException.printStackTrace();
      deleteDirectory(new File("/data/data/" + paramContext.getPackageName() + "/.cache/"));
      File localFile2 = new File("/data/data/" + paramContext.getPackageName() + "/.sec_version");
      if (localFile2.exists())
      {
        localFile2.delete();
        return;
        int j = Integer.parseInt(arrayOfString[0]);
        if ((!arrayOfString[1].equals(str)) || (j != i))
        {
          deleteDirectory(localFile1);
          localFile3.delete();
        }
      }
    }
  }
  
  private static void checkX86(Context paramContext)
  {
    if (getCPUABI().equals("x86")) {
      isX86 = true;
    }
    if (isX86) {
      if (!new File("/data/data/" + paramContext.getPackageName() + "/.cache/" + paramContext.getPackageName()).exists()) {
        CopyLib(paramContext);
      }
    }
    while (new File("/data/data/" + paramContext.getPackageName() + "/.cache/" + "libsecexe.so").exists()) {
      return;
    }
    CopyArmLib(paramContext);
  }
  
  private static void copyJarFile(Context paramContext)
  {
    String str = "/data/data/" + paramContext.getPackageName() + "/.cache/classes.jar";
    try
    {
      JarFile localJarFile = new JarFile(paramContext.getApplicationInfo().sourceDir);
      ZipEntry localZipEntry = localJarFile.getEntry("assets/bangcle_classes.jar");
      File localFile = new File(str);
      byte[] arrayOfByte = new byte[65536];
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(localJarFile.getInputStream(localZipEntry));
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(localFile));
      for (;;)
      {
        int i = localBufferedInputStream.read(arrayOfByte);
        if (i <= 0)
        {
          localBufferedOutputStream.flush();
          localBufferedOutputStream.close();
          localBufferedInputStream.close();
          return;
        }
        localBufferedOutputStream.write(arrayOfByte, 0, i);
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  private static void createChildProcess(Context paramContext)
  {
    String str = paramContext.getApplicationInfo().sourceDir;
    ACall.getACall().r1(paramContext.getPackageName().getBytes(), str.getBytes());
  }
  
  private static boolean deleteDirectory(File paramFile)
  {
    File[] arrayOfFile;
    int i;
    if (paramFile.exists())
    {
      arrayOfFile = paramFile.listFiles();
      i = 0;
      if (i < arrayOfFile.length) {}
    }
    else
    {
      return paramFile.delete();
    }
    if (arrayOfFile[i].isDirectory()) {
      deleteDirectory(arrayOfFile[i]);
    }
    for (;;)
    {
      i++;
      break;
      arrayOfFile[i].delete();
    }
  }
  
  public static void doCheck(Context paramContext)
  {
    ApplicationInfo localApplicationInfo = paramContext.getApplicationInfo();
    File localFile = new File(localApplicationInfo.dataDir, ".md5");
    String str1 = "/data/dalvik-cache/";
    byte[] arrayOfByte1 = null;
    if (new File("/data/dalvik-cache/arm/").exists()) {
      str1 = "/data/dalvik-cache/arm/";
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(new String(localApplicationInfo.sourceDir), "/");
    String str2;
    if (!localStringTokenizer.hasMoreTokens()) {
      str2 = new StringBuilder(String.valueOf(str1)).append("classes").toString() + ".dex";
    }
    for (;;)
    {
      try
      {
        arrayOfByte1 = toASC(calFileMD5(str2));
        if (localFile.exists()) {
          continue;
        }
        i = 0;
        if (arrayOfByte1 != null)
        {
          FileOutputStream localFileOutputStream2 = new FileOutputStream(localFile);
          localFileOutputStream2.write(arrayOfByte1);
          localFileOutputStream2.close();
          i = 1;
        }
      }
      catch (Exception localException1)
      {
        byte[] arrayOfByte2;
        int j;
        int k;
        int m;
        int n;
        localException1.printStackTrace(System.out);
        int i = 0;
        continue;
      }
      if (i != 0) {
        deleteDirectory(new File("/data/data/" + paramContext.getPackageName() + "/.cache/"));
      }
      try
      {
        FileOutputStream localFileOutputStream1 = new FileOutputStream(localFile);
        localFileOutputStream1.write(arrayOfByte1);
        localFileOutputStream1.close();
        return;
      }
      catch (Exception localException2) {}
      System.out.println();
      str1 = new StringBuilder(String.valueOf(str1)).append(localStringTokenizer.nextToken()).toString() + "@";
      break;
      i = 0;
      if (arrayOfByte1 != null)
      {
        arrayOfByte2 = readFile(localFile);
        i = 0;
        if (arrayOfByte2 != null) {
          if (arrayOfByte2.length == arrayOfByte1.length)
          {
            j = 0;
            k = arrayOfByte2.length;
            i = 0;
            if (j < k)
            {
              m = arrayOfByte2[j];
              n = arrayOfByte1[j];
              if (m != n) {
                i = 1;
              } else {
                j++;
              }
            }
          }
          else
          {
            i = 1;
          }
        }
      }
    }
  }
  
  public static void doProvider()
  {
    synchronized (ps)
    {
      ACall.getACall().set4();
      return;
    }
  }
  
  private static void getAssetFile(Context paramContext, String paramString1, String paramString2)
  {
    File localFile = new File(paramString2);
    if (!localFile.exists()) {
      try
      {
        localFile.createNewFile();
        InputStream localInputStream = paramContext.getAssets().open(paramString1);
        FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
        byte[] arrayOfByte = new byte[4096];
        for (;;)
        {
          int i = localInputStream.read(arrayOfByte);
          if (i == -1)
          {
            localFileOutputStream.close();
            localInputStream.close();
            return;
          }
          localFileOutputStream.write(arrayOfByte, 0, i);
        }
        return;
      }
      catch (IOException localIOException)
      {
        localIOException.printStackTrace();
        localFile.delete();
      }
    }
  }
  
  public static String getCPUABI()
  {
    if (CPUABI == null) {
      try
      {
        if (new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("getprop ro.product.cpu.abi").getInputStream())).readLine().contains("x86")) {}
        for (CPUABI = "x86";; CPUABI = "arm") {
          return CPUABI;
        }
      }
      catch (Exception localException)
      {
        for (;;)
        {
          CPUABI = "arm";
        }
      }
    }
    return CPUABI;
  }
  
  public static String getCPUinfo()
  {
    localObject = "";
    try
    {
      InputStream localInputStream = new ProcessBuilder(new String[] { "/system/bin/cat", "/proc/cpuinfo" }).start().getInputStream();
      byte[] arrayOfByte = new byte[1024];
      for (;;)
      {
        if (localInputStream.read(arrayOfByte) == -1)
        {
          localInputStream.close();
          return localObject;
        }
        String str = localObject + new String(arrayOfByte);
        localObject = str;
      }
      return localObject;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
  
  private static long getClassesJarSize(Context paramContext)
  {
    try
    {
      long l = new JarFile(paramContext.getApplicationInfo().sourceDir).getJarEntry("assets/bangcle_classes.jar").getSize();
      return l;
    }
    catch (Exception localException) {}
    return 0L;
  }
  
  public static ClassLoader getCustomClassLoader()
  {
    return cl;
  }
  
  private static long getDataSize()
  {
    StatFs localStatFs = new StatFs(Environment.getDataDirectory().getPath());
    return localStatFs.getAvailableBlocks() * localStatFs.getBlockSize();
  }
  
  public static Field getField(Class<?> paramClass, String paramString)
  {
    Field[] arrayOfField = paramClass.getDeclaredFields();
    int i = arrayOfField.length;
    for (int j = 0;; j++)
    {
      Field localField;
      if (j >= i) {
        localField = null;
      }
      do
      {
        return localField;
        localField = arrayOfField[j];
        if (!localField.isAccessible()) {
          localField.setAccessible(true);
        }
      } while (localField.getName().equals(paramString));
    }
  }
  
  public static Object getFieldValue(Class<?> paramClass, Object paramObject, String paramString)
  {
    try
    {
      Object localObject = getField(paramClass, paramString).get(paramObject);
      return localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
  
  private static boolean isSpaceEnough(Context paramContext)
  {
    String str1 = "/data/data/" + paramContext.getPackageName() + "/.cache/classes.jar";
    String str2 = "/data/data/" + paramContext.getPackageName() + "/.cache/classes.dex";
    File localFile1 = new File(str1);
    File localFile2 = new File(str2);
    if ((localFile1.exists()) && (localFile2.exists())) {}
    long l;
    do
    {
      return true;
      l = getDataSize();
    } while (4L * getClassesJarSize(paramContext) <= l);
    return false;
  }
  
  public static byte[] readFile(File paramFile)
    throws Exception
  {
    FileInputStream localFileInputStream = new FileInputStream(paramFile);
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte[32768];
    for (;;)
    {
      int i = localFileInputStream.read(arrayOfByte);
      if (i <= 0) {
        return localByteArrayOutputStream.toByteArray();
      }
      localByteArrayOutputStream.write(arrayOfByte, 0, i);
    }
  }
  
  private static String[] readVersions(File paramFile)
  {
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new FileReader(paramFile));
      String[] arrayOfString = new String[2];
      arrayOfString[0] = localBufferedReader.readLine();
      arrayOfString[1] = localBufferedReader.readLine();
      localBufferedReader.close();
      return arrayOfString;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }
  
  public static void realCopy(String paramString, JarFile paramJarFile, ZipEntry paramZipEntry)
  {
    try
    {
      File localFile = new File(paramString);
      byte[] arrayOfByte = new byte[65536];
      BufferedInputStream localBufferedInputStream = new BufferedInputStream(paramJarFile.getInputStream(paramZipEntry));
      BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(new FileOutputStream(localFile));
      for (;;)
      {
        int i = localBufferedInputStream.read(arrayOfByte);
        if (i <= 0)
        {
          localBufferedOutputStream.flush();
          localBufferedOutputStream.close();
          localBufferedInputStream.close();
          return;
        }
        localBufferedOutputStream.write(arrayOfByte, 0, i);
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public static void runAll(Context paramContext)
  {
    x86Ctx = paramContext;
    doCheck(paramContext);
    checkUpdate(paramContext);
    try
    {
      File localFile = new File("/data/data/" + paramContext.getPackageName() + "/.cache/");
      if (!localFile.exists()) {
        localFile.mkdir();
      }
      checkX86(paramContext);
      CopyBinaryFile(paramContext);
      createChildProcess(paramContext);
      tryDo(paramContext);
      runPkg(paramContext, paramContext.getPackageName());
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
  }
  
  public static void runAll1(Context paramContext)
  {
    try
    {
      File localFile = new File("/data/data/" + paramContext.getPackageName() + "/.cache/");
      if (!localFile.exists()) {
        localFile.mkdir();
      }
      checkX86(paramContext);
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
  }
  
  private static void runPkg(Context paramContext, String paramString)
  {
    String str;
    if (Build.VERSION.SDK_INT >= 20) {
      str = paramContext.getApplicationInfo().nativeLibraryDir;
    }
    try
    {
      for (;;)
      {
        if (cl == null)
        {
          if (!isX86) {
            break;
          }
          cl = new MyClassLoader("/data/data/" + paramString + "/.cache/classes.jar", "/data/data/" + paramString + "/.cache", str, paramContext.getClassLoader());
        }
        return;
        str = "/data/data/" + paramString + "/lib/";
      }
      cl = new MyClassLoader("/data/data/" + paramString + "/.cache/classes.jar", "/data/data/" + paramString + "/.cache", str, paramContext.getClassLoader());
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public static void setFieldValue(Class<?> paramClass, Object paramObject1, String paramString, Object paramObject2)
  {
    System.out.println("setFieldValue" + paramClass + paramObject1 + paramString + paramObject2);
    if (paramString == null) {
      return;
    }
    try
    {
      Field localField = getField(paramClass, paramString);
      localField.setAccessible(true);
      localField.set(paramObject1, paramObject2);
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public static byte[] toASC(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = new byte[2 * paramArrayOfByte.length];
    for (int i = 0;; i++)
    {
      if (i >= paramArrayOfByte.length) {
        return arrayOfByte;
      }
      int j = paramArrayOfByte[i];
      arrayOfByte[(i * 2)] = hexDigits[(0xF & j >> 4)];
      arrayOfByte[(1 + i * 2)] = hexDigits[(j & 0xF)];
    }
  }
  
  private static void tryDo(Context paramContext)
  {
    String str = paramContext.getApplicationInfo().sourceDir;
    ACall.getACall().r2(paramContext.getPackageName().getBytes(), str.getBytes(), paramContext.getApplicationInfo().processName.getBytes());
  }
  
  private static void writeVersion(File paramFile, int paramInt, String paramString)
  {
    try
    {
      BufferedWriter localBufferedWriter = new BufferedWriter(new FileWriter(paramFile));
      localBufferedWriter.write(Integer.toString(paramInt));
      localBufferedWriter.newLine();
      localBufferedWriter.write(paramString);
      localBufferedWriter.flush();
      localBufferedWriter.close();
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_bangbang.jar
 * Qualified Name:     com.bangcle.protect.Util
 * JD-Core Version:    0.7.0.1
 */