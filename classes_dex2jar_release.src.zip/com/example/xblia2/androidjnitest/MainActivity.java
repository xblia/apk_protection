package com.example.xblia2.androidjnitest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.util.Utils;
import java.util.Random;

public class MainActivity
  extends ActionBarActivity
  implements View.OnClickListener
{
  private Button calcBtn;
  private EditText editNumber1;
  private EditText editNumber2;
  private EditText editTrace;
  private Button jniWriteBtn;
  private Button startBoradcastBtn;
  private Button startServiceBtn;
  private TextView tvResult;
  
  private void calc()
  {
    String str1 = this.editNumber1.getText().toString();
    String str2 = this.editNumber2.getText().toString();
    if ((str1 != null) && (!str1.isEmpty()) && (str2 != null) && (!str2.isEmpty())) {
      try
      {
        int i = Utils.calc(Integer.parseInt(str1), Integer.parseInt(str2));
        this.tvResult.setText("Result: " + i);
        return;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        localNumberFormatException.printStackTrace();
        toastInfo(localNumberFormatException.getMessage());
        return;
      }
    }
    toastInfo("Value1 and Value2 input values must be number.");
  }
  
  private void printTrace(String paramString)
  {
    this.editTrace.append(paramString + System.getProperty("line.separator"));
    this.editTrace.setSelection(this.editTrace.getText().length(), this.editTrace.getText().length());
  }
  
  private void toastInfo(String paramString)
  {
    Toast.makeText(this, paramString, 0).show();
  }
  
  public void initView()
  {
    this.editNumber1 = ((EditText)findViewById(2131492948));
    this.editNumber2 = ((EditText)findViewById(2131492951));
    this.calcBtn = ((Button)findViewById(2131492953));
    this.jniWriteBtn = ((Button)findViewById(2131492959));
    this.startServiceBtn = ((Button)findViewById(2131492960));
    this.startBoradcastBtn = ((Button)findViewById(2131492961));
    this.tvResult = ((TextView)findViewById(2131492954));
    this.editTrace = ((EditText)findViewById(2131492957));
    this.calcBtn.setOnClickListener(this);
    this.jniWriteBtn.setOnClickListener(this);
    this.startServiceBtn.setOnClickListener(this);
    this.startBoradcastBtn.setOnClickListener(this);
    this.tvResult.setText(Utils.stringFromJNI());
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131492954: 
    case 2131492955: 
    case 2131492956: 
    case 2131492957: 
    case 2131492958: 
    default: 
      return;
    case 2131492953: 
      calc();
      return;
    case 2131492959: 
      Utils.writeContentToFile("Write File from JNI.");
      printTrace("Write info to file by JNI access, random number: " + new Random().nextInt());
      return;
    case 2131492960: 
      Intent localIntent2 = new Intent();
      localIntent2.setClass(getApplicationContext(), JNIService.class);
      startService(localIntent2);
      return;
    }
    Intent localIntent1 = new Intent();
    localIntent1.setAction("com.intel.cats.jni.broadcast.action");
    sendBroadcast(localIntent1);
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130968601);
    initView();
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131558400, paramMenu);
    return true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    if (paramMenuItem.getItemId() == 2131492975) {
      return true;
    }
    return super.onOptionsItemSelected(paramMenuItem);
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     com.example.xblia2.androidjnitest.MainActivity
 * JD-Core Version:    0.7.0.1
 */