package android.support.v4.app;

public class ServiceCompat
{
  public static final int START_STICKY = 1;
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.app.ServiceCompat
 * JD-Core Version:    0.7.0.1
 */