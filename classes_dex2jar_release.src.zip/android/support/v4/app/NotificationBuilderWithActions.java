package android.support.v4.app;

abstract interface NotificationBuilderWithActions
{
  public abstract void addAction(NotificationCompatBase.Action paramAction);
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.app.NotificationBuilderWithActions
 * JD-Core Version:    0.7.0.1
 */