package android.support.v4.media;

public class TransportStateListener
{
  public void onPlayingChanged(TransportController paramTransportController) {}
  
  public void onTransportControlsChanged(TransportController paramTransportController) {}
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.media.TransportStateListener
 * JD-Core Version:    0.7.0.1
 */