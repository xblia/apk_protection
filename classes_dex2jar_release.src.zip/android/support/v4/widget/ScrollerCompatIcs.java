package android.support.v4.widget;

import android.widget.OverScroller;

class ScrollerCompatIcs
{
  public static float getCurrVelocity(Object paramObject)
  {
    return ((OverScroller)paramObject).getCurrVelocity();
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.widget.ScrollerCompatIcs
 * JD-Core Version:    0.7.0.1
 */