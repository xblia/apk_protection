package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatApi22
{
  public static Drawable wrapForTinting(Drawable paramDrawable)
  {
    return paramDrawable;
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.graphics.drawable.DrawableCompatApi22
 * JD-Core Version:    0.7.0.1
 */