package com.example.xblia2.androidjnitest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class JNIReceiver
  extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str = paramIntent.getAction();
    if (str.equals("com.intel.cats.jni.broadcast.action"))
    {
      Toast.makeText(paramContext, "JNI_BroadcastReciver valid.", 0).show();
      Log.e("JNI_TEST", "JNI_BroadcastReciver valid.");
      return;
    }
    Toast.makeText(paramContext, "JNI_BroadcastReciver" + str, 0).show();
    Log.e("JNI_TEST", "JNI_BroadcastReciver valid.");
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     com.example.xblia2.androidjnitest.JNIReceiver
 * JD-Core Version:    0.7.0.1
 */