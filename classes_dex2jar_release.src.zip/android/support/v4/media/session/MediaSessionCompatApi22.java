package android.support.v4.media.session;

import android.media.session.MediaSession;

class MediaSessionCompatApi22
{
  public static void setRatingType(Object paramObject, int paramInt)
  {
    ((MediaSession)paramObject).setRatingType(paramInt);
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.media.session.MediaSessionCompatApi22
 * JD-Core Version:    0.7.0.1
 */