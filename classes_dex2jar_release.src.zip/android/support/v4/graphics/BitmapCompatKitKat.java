package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompatKitKat
{
  static int getAllocationByteCount(Bitmap paramBitmap)
  {
    return paramBitmap.getAllocationByteCount();
  }
}


/* Location:           E:\bangbang_protection\jar\classes_dex2jar_release.jar
 * Qualified Name:     android.support.v4.graphics.BitmapCompatKitKat
 * JD-Core Version:    0.7.0.1
 */